using UnityEngine;

public class SoundManager : MonoBehaviour
{
    public static SoundManager instance { get; private set; }
    private AudioSource sound;
    private AudioSource music;

    private void Awake()
    {
        sound = GetComponent<AudioSource>();
        music = transform.GetChild(0).GetComponent<AudioSource>();

        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else if (instance != null && instance != this)
            Destroy(gameObject);
    }

    public void PlaySoundEffect(AudioClip soundEffect)
    {
        sound.PlayOneShot(soundEffect);
    }

    public void changeSoundVolume(float volume)
    {
        float currentVolume = PlayerPrefs.GetFloat("soundVolume", 0.6f);
        currentVolume += volume;

        if (currentVolume > 1)
            currentVolume = 0;
        else if (currentVolume < 0)
            currentVolume = 1;

        sound.volume = currentVolume;
        PlayerPrefs.SetFloat("soundVolume", currentVolume);
    }
    
    public void changeMusicVolume(float volume)
    {
        float currentVolume = PlayerPrefs.GetFloat("musicVolume", 0.2f);
        currentVolume += volume;

        if (currentVolume > 1)
            currentVolume = 0;
        else if (currentVolume < 0)
            currentVolume = 1;

        music.volume = currentVolume;
        PlayerPrefs.SetFloat("musicVolume", currentVolume);
    }
}
