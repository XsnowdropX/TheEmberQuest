using UnityEngine;

public class CameraController : MonoBehaviour
{
    //room camera
    [SerializeField] private float speed;
    private float currentPosX;
    private Vector3 velocity = Vector3.zero;

    //player following camera
    [SerializeField] private Transform player;
    [SerializeField] private float aheadDistanceX;
    [SerializeField] private float verticalOffsetY;
    [SerializeField] private float cameraSpeed;
    private float lookAhead;

    private void Update()
    {
        //transform.position = Vector3.SmoothDamp(transform.position, new Vector3(currentPosX, transform.position.y, transform.position.z), ref velocity, speed);
        //throwing italian hands at how decentralized the room is - will need fixing
        transform.position = new Vector3(player.position.x + lookAhead, player.position.y+ verticalOffsetY, transform.position.z); //player.position.y+lookAhead
        lookAhead = Mathf.Lerp(lookAhead, (aheadDistanceX *  player.localScale.x), Time.deltaTime * cameraSpeed);
    }

    public void MoveToNewRoom(Transform _newRoom)
    {
        currentPosX = _newRoom.position.x;
    }
}
