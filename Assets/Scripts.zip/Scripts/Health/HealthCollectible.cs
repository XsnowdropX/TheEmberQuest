using UnityEngine;

public class HealthCollectible : MonoBehaviour
{
    [SerializeField] private float healthValue;
    [SerializeField] private AudioClip collectingSound;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "Player")
        {
            SoundManager.instance.PlaySoundEffect(collectingSound);
            collision.GetComponent<Health>().Heal(healthValue);
            gameObject.SetActive(false);
        }
    }
}
